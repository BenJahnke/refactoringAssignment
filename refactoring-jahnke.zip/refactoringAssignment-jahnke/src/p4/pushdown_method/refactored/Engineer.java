package p4.pushdown_method.refactored;

public class Engineer extends Employee {
}
